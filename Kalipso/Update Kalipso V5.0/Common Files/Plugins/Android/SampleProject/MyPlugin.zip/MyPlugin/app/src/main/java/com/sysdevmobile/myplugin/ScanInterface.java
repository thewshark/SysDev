package com.sysdevmobile.myplugin;

import android.app.Activity;
import android.content.Context;
import android.view.KeyEvent;

import com.sysdevsolutions.external.kclientv50.KExternalEventsHandler;
import com.sysdevsolutions.external.kclientv50.KExternalEventsInterface;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPI;
import com.sysdevsolutions.external.kclientv50.KExternalScannerAPIException;

import java.util.ArrayList;

public class ScanInterface extends KExternalEventsHandler implements KExternalScannerAPI {
    private KExternalEventsInterface mEventsInterface = null;

    //************************ Implementation of Kalipso Barcode actions

    /**
     * Called to Connect to the barcode scanner
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param act Current activity. It may be required by the implementation.
     *
     * @param connectionType The type of connection with the RFID device
     *
     * @param address The address of the RFID device.
     *                For Bluetooth is the device MC address
     *                For Socket is the IP or name
     *                For Serial is the device string
     *
     * @param userParameters User parameters
     *
     * @param eventsInterface Interface so you can trigger events in Kalipso.
     */
    @Override
    public void Connect(Context ctx, Activity act, ConnectionType connectionType, String address, String userParameters, KExternalEventsInterface eventsInterface) throws KExternalScannerAPIException
    {
        //Use this variable to send Barcode Scan events back to Kalipso
        //For example calling mEventsInterface.BarcodeScanned("barcodeString", barcodeType, "userParameter");
        mEventsInterface=eventsInterface;
        eventsInterface.AddOnAppEventListener(this);

        //Add your Barcode initialization code here
        throw new KExternalScannerAPIException("Not implemented");
    }


    /**
     * Called to disconnect from the barcode scanner
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param userParameters Generic parameters to use as you want.
     */
    @Override
    public void Disconnect(Context ctx, String userParameters) throws KExternalScannerAPIException
    {
        throw new KExternalScannerAPIException("Not implemented");
    }


    /**
     * Called to enabled/disable the scanner
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param enabled indicates to enable or disable the scanner
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return Should return 0 for false or 1 for true
     *          but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabled(Context ctx, boolean enabled, String userParameters) throws KExternalScannerAPIException
    {
        throw new KExternalScannerAPIException("Not implemented");
    }


    /**
     * Called to wait for a barcode scan. Add the results to the Lists of scannedBarcodes and types to the list of scannedBarcodeTypes
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param timeOut Maximum time in milliseconds to wait for the sacnner
     *
     * @param softTrigger If true, scanning will begin immediately by using a software trigger.
     *                    If false the user has to press the scan button to start scanning
     *
     * @param scannedBarcodes When called this will be an empty list, on return should have the scanned barcode.
     *                        If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     *
     * @param scannedBarcodeTypes When called this will be an empty list, on return should have the scanned barcode.
     *                        If it has more than one entry in the list, Kalipso will receive this list as a String list separated by CR char
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return Should return 0 for false or 1 for true
     *          but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void ScanBarcode(Context ctx, int timeOut, boolean softTrigger, ArrayList<String> scannedBarcodes, ArrayList<String> scannedBarcodeTypes, String userParameters) throws KExternalScannerAPIException
    {
        throw new KExternalScannerAPIException("Not implemented");
    }


    /**
     * Called to set the enabled symbologies
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param symbologiesList list of symbologies to enable with Kalipso IDs. You will need to convert to the scanner IDs
     *
     * @param symbologiesCount number of entries in symbologiesList array
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return Should return 0 for false or 1 for true
     *          but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void SetEnabledSymbologies(Context ctx, int[] symbologiesList, int symbologiesCount, String userParameters) throws KExternalScannerAPIException
    {
        throw new KExternalScannerAPIException("Not implemented");
    }


    //Called to get the enabled symbologies. They should be returned in symbologiesList[] and the function result should be the number of symbologies passed in symbologiesList[]
    /**
     * Called to get the enabled symbologies
     *
     * @param ctx Current context. It may be required by the implementation.
     *
     * @param symbologiesList When called this will be an empty list, on return should have the list of enabled symbologies with Kalipso IDs. You will need to convert from the scanner IDs
     *
     * @param userParameters Generic parameters to use as you want.
     *
     * @return Should return 0 for false or 1 for true
     *          but additional values can be returned if you want to differentiate between more connection states
     */
    @Override
    public void GetEnabledSymbologies(Context ctx, ArrayList<Integer> symbologiesList, String userParameters) throws KExternalScannerAPIException
    {
        throw new KExternalScannerAPIException("Not implemented");
    }



    //************************ Events reported from Kalipso through KExternalEventsHandler
    @Override
    public void onAppPaused(Context ctx)
    {
    }

    @Override
    public void onAppResumed(Context ctx)
    {
    }

    @Override
    public void onKeyDown(Activity act, int keyCode, KeyEvent event)
    {
    }

    @Override
    public void onKeyUp(Activity act, int keyCode, KeyEvent event)
    {
    }
}
