#include "SampleVideoView.h"
#include "jni.h"

#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, "SampleVideoView", __VA_ARGS__))
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, "SampleVideoView", __VA_ARGS__))

jobject videoView = NULL;

int createControl(JNIEnv* env, jobject activity, jobject viewGroup, jobject placeHolderView)
{
	if (env == NULL)
		return 91;

	if (activity == NULL)
		return 92;

	if (viewGroup == NULL)
		return 93;

	if (placeHolderView == NULL)
		return 94;

	if (videoView != NULL)
	{
		env->DeleteGlobalRef(videoView);
		videoView = NULL;
	}

	//Create Media Controller
	jclass MediaController = env->FindClass("android/widget/MediaController");
	jmethodID MediaController_Constructor = env->GetMethodID(MediaController, "<init>", "(Landroid/content/Context;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 94;
	}
	jobject mediaController = env->NewObject(MediaController, MediaController_Constructor, activity);
	if (env->ExceptionCheck() || mediaController == NULL)
	{
		env->ExceptionClear();
		return 95;
	}


	//Create videoView
	jclass VideoView = env->FindClass("android/widget/VideoView");
	jmethodID VideoView_Constructor = env->GetMethodID(VideoView, "<init>", "(Landroid/content/Context;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 94;
	}


	videoView = env->NewGlobalRef(env->NewObject(VideoView, VideoView_Constructor, activity));
	if (env->ExceptionCheck() || videoView == NULL)
	{
		env->ExceptionClear();
		return 95;
	}


	//Set VideoView MediaController
	jmethodID ViewGroup_setMediaController = env->GetMethodID(VideoView, "setMediaController", "(Landroid/widget/MediaController;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 99;
	}


	env->CallVoidMethod(videoView, ViewGroup_setMediaController, mediaController);

	
	jmethodID MediaController_setMediaPlayer = env->GetMethodID(MediaController, "setMediaPlayer", "(Landroid/widget/MediaController$MediaPlayerControl;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 94;
	}

	env->CallVoidMethod(mediaController, MediaController_setMediaPlayer, videoView);


	//Get Layout Params from Placholder
	jclass View = env->FindClass("android/view/View");
	jmethodID View_getLayoutParams = env->GetMethodID(View, "getLayoutParams", "()Landroid/view/ViewGroup$LayoutParams;");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 98;
	}

	jobject layout_params=env->CallObjectMethod(placeHolderView, View_getLayoutParams);


	//Will use framelayout so video stays centered in framelayout.
	//Create FrameLayout
	jclass FrameLayout = env->FindClass("android/widget/FrameLayout");
	jmethodID FrameLayout_Constructor = env->GetMethodID(FrameLayout, "<init>", "(Landroid/content/Context;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 94;
	}


	jobject framelayout = env->NewObject(FrameLayout, FrameLayout_Constructor, activity);
	if (env->ExceptionCheck() || framelayout == NULL)
	{
		env->ExceptionClear();
		return 95;
	}
	
	//Set framelayout params equals to the placeholder layout params
	jmethodID View_setLayoutParams = env->GetMethodID(View, "setLayoutParams", "(Landroid/view/ViewGroup$LayoutParams;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 98;
	}
	env->CallVoidMethod(framelayout, View_setLayoutParams, layout_params);


	jclass ViewGroup = env->FindClass("android/view/ViewGroup");
	jmethodID ViewGroup_AddView = env->GetMethodID(ViewGroup, "addView", "(Landroid/view/View;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 99;
	}

	//Add framelayout to Kalipso
	env->CallVoidMethod(viewGroup, ViewGroup_AddView, framelayout);




	//Create FrameLayout Params to put video into framelayout
	jclass FrameLayout_LayoutParams = env->FindClass("android/widget/FrameLayout$LayoutParams");
	jmethodID FrameLayout_LayoutParams_Constructor = env->GetMethodID(FrameLayout_LayoutParams, "<init>", "(III)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 94;
	}

	int MATCH_PARENT = -1;
	int GRAVITY_CENTER = 17;
	jobject framelayout_params = env->NewObject(FrameLayout_LayoutParams, FrameLayout_LayoutParams_Constructor, MATCH_PARENT, MATCH_PARENT, GRAVITY_CENTER);
	if (env->ExceptionCheck() || framelayout == NULL)
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, View_setLayoutParams, framelayout_params);

	//Add videoView to Framelayout
	env->CallVoidMethod(framelayout, ViewGroup_AddView, videoView);






	jmethodID View_setBackgroundColor = env->GetMethodID(View, "setBackgroundColor", "(I)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 98;
	}

	
	env->CallVoidMethod(videoView, View_setBackgroundColor, (__uint32_t)0xFF000000);//Black

	return 0;
}

int deleteControl(JNIEnv* env, jobject viewGroup)
{
	if (videoView == NULL)
		return 1;

	if (viewGroup == NULL)
		return 93;

	jclass VideoView = env->FindClass("android/widget/VideoView");
	jmethodID VideoView_stopPlayback = env->GetMethodID(VideoView, "stopPlayback", "()V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, VideoView_stopPlayback);

	jclass ViewGroup = env->FindClass("android/view/ViewGroup");
	jmethodID ViewGroup_RemoveView = env->GetMethodID(ViewGroup, "removeView", "(Landroid/view/View;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 99;
	}

	env->CallVoidMethod(viewGroup, ViewGroup_RemoveView, videoView);

	env->DeleteGlobalRef(videoView);
	videoView = NULL;

	return 0;
}

int playVideo(JNIEnv* env, char * videoPath)
{
	if (videoView == NULL)
		return 1;

	jclass VideoView = env->FindClass("android/widget/VideoView");
	jmethodID VideoView_setVideoPath = env->GetMethodID(VideoView, "setVideoPath", "(Ljava/lang/String;)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 94;
	}

	env->CallVoidMethod(videoView, VideoView_setVideoPath, env->NewStringUTF(videoPath));


	jmethodID VideoView_seekTo = env->GetMethodID(VideoView, "seekTo", "(I)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, VideoView_seekTo, 100);//100 ms


	jmethodID VideoView_start = env->GetMethodID(VideoView, "start", "()V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, VideoView_start);

	jclass View = env->FindClass("android/view/View");
	jmethodID View_setBackgroundColor = env->GetMethodID(View, "setBackgroundColor", "(I)V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 98;
	}
	env->CallVoidMethod(videoView, View_setBackgroundColor, (__uint32_t)0x00000000);//Transparent

	return 0;
}

int stopVideo(JNIEnv* env)
{
	if (videoView == NULL)
		return 1;

	jclass VideoView = env->FindClass("android/widget/VideoView");
	jmethodID VideoView_stopPlayback = env->GetMethodID(VideoView, "stopPlayback", "()V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, VideoView_stopPlayback);


	return 0;
}

int pauseVideo(JNIEnv* env)
{
	if (videoView == NULL)
		return 1;

	jclass VideoView = env->FindClass("android/widget/VideoView");
	jmethodID VideoView_pause = env->GetMethodID(VideoView, "pause", "()V");
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, VideoView_pause);


	return 0;
}

int resumeVideo(JNIEnv* env)
{
	if (videoView == NULL)
		return 1;

	jclass VideoView = env->FindClass("android/widget/VideoView");
	jmethodID VideoView_resume = env->GetMethodID(VideoView, "start", "()V");//resume method did not work. so use Start and it will continue from where it paused
	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
		return 95;
	}

	env->CallVoidMethod(videoView, VideoView_resume);


	return 0;
}