#pragma once

extern "C" {
	extern int createControl(JNIEnv* env, jobject activity, jobject viewGroup, jobject placeHolderView);
	extern int deleteControl(JNIEnv* env, jobject viewGroup);
	extern int playVideo(JNIEnv* env, char * videoPath);
	extern int stopVideo(JNIEnv* env);
	extern int pauseVideo(JNIEnv* env);
	extern int resumeVideo(JNIEnv* env);
}
