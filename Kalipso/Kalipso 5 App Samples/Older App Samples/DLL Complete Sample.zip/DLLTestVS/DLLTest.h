// DLLTest.h : main header file for the DLLTest DLL
//

#if !defined(AFX_DLLTest_H__4F30764C_2869_4439_A66E_80166C4FD75C__INCLUDED_)
#define AFX_DLLTest_H__4F30764C_2869_4439_A66E_80166C4FD75C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDLLTestApp
// See DLLTest.cpp for the implementation of this class
//

class CDLLTestApp : public CWinApp
{
public:
	CDLLTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDLLTestApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CDLLTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG

#ifndef _WIN32_WCE
	virtual BOOL InitInstance();
#endif
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLLTest_H__4F30764C_2869_4439_A66E_80166C4FD75C__INCLUDED_)
